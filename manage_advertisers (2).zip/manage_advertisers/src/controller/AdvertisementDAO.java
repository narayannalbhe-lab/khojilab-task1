package controller;

import java.sql.*;
import java.util.*;

public class AdvertisementDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/AdverData?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Root@123";
    private Connection jdbcConnection;

    public AdvertisementDAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        }
    }

    public void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }

    public List<Advertisement> getAllAdvertisements() throws SQLException {
        List<Advertisement> advertisements = new ArrayList<>();
        String sql = "SELECT * FROM Advertisement_Details";
        connect();
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            int id = resultSet.getInt("Adv_id");
            String name = resultSet.getString("Adv_name");
            String vendor = resultSet.getString("Adv_Vendor");
            String category = resultSet.getString("Adv_Category");
            String mobile = resultSet.getString("Adv_Mob");
            String alternateMobile = resultSet.getString("Adv_Alternate_Mob");
            String email = resultSet.getString("Adv_email");
            String image = resultSet.getString("Adv_Images");

            Advertisement advertisement = new Advertisement(id, name, vendor, category, mobile, alternateMobile, email, image);
            advertisements.add(advertisement);
        }
        resultSet.close();
        statement.close();
        disconnect();
        return advertisements;
    }
}
